# Donation Management System – Distributed Computing Lab (Q29–Q35)

## Requirements
- Python 3
- Linux terminal
- No third-party Python packages required

## Run
Open this directory in a terminal and run one command at a time:

```bash
python3 q29_lamport.py
python3 q30_mpi_scatter_gather.py
python3 q31_ring_election.py
python3 q32_cristian.py
python3 q33_rpc.py
python3 q34_bully_election.py
python3 q35_berkeley.py
```

Each script reads its matching CSV in the same directory.

## Manual-specific assumptions and limitations

### Q29 Lamport
The manual's CSV columns do not include message IDs or explicit message timestamps. This demonstration uses FIFO queues keyed by sender/receiver pair. A RECEIVE row consumes the oldest queued message from the process named in `message_to`. For the supplied sample, `message_to` on a RECEIVE row means the sender.

### Q30 MPI-style matrix multiplication
The manual specifies one matrix CSV only. Matrix multiplication requires two matrices, so this program computes A x A-transpose. Python ThreadPoolExecutor simulates master/worker scatter-gather; it is not an actual MPI deployment or multi-machine MPI cluster.

### Q31 Ring election
The CSV's next_node_id values define the ring. Inactive nodes are skipped. The final leader is the active node with the highest ID, as required by the chit.

### Q32 Cristian
The CSV gives request-send time, server time and response-receive time. The example assumes symmetric network delay, so estimated server time at reception is server time + RTT/2. The supplied values are a simplified simulation.

### Q33 RPC
This is a local RPC/RMI-style dispatcher simulation, not a network socket implementation. The CSV parameter is marshalled from text to a number; a server-side function is called; the result is returned.

### Q34 Bully
The simulation reads alive status from CSV and elects the highest-ID alive node. The initiator is the lowest-ID active node to demonstrate the ELECTION and OK exchanges.

### Q35 Berkeley
Rows marked faulty are excluded. The master averages the remaining clock readings and calculates each valid node's adjustment as average - local clock.

## Viva preparation – key concepts

### Distributed systems
A distributed system is a collection of independent computers/processes that communicate over a network and appear to users as one system. Examples include banking, donation platforms, cloud services and distributed databases.

### Process vs thread
A process has its own address space and resources. Threads are execution paths within a process and usually share its memory. Processes communicate using IPC/message passing; threads often communicate through shared memory and synchronization primitives.

### Physical vs logical clocks
Physical clocks represent real time and can drift because hardware clocks are imperfect. Logical clocks do not measure wall-clock time; they capture event ordering and causality.

### Lamport clock
Rule: increment before each local/send event. On receive, set clock = max(local clock, received timestamp) + 1. If a happens-before b, then L(a) < L(b). The reverse is not guaranteed: L(a) < L(b) does not prove a caused b.

### Vector clock
A vector clock keeps one counter per process. On a local event, increment the local component. On send, attach the vector. On receive, take the component-wise maximum of local and received vectors, then increment the receiver's own component. Vector clocks can distinguish causality from concurrency; Lamport clocks cannot.

### Scatter and gather
Scatter distributes pieces of input/work from a master to workers. Gather collects worker results at the master. Amdahl's law explains why speedup is limited by the serial portion of a program.

### MPI
MPI means Message Passing Interface. It is a standard API for communication between processes, commonly used in high-performance computing. This lab's ThreadPoolExecutor is a simulation of the pattern, not actual MPI.

### Ring election
Nodes are arranged in a logical ring. An election message circulates and gathers candidate IDs. The highest active ID wins in this lab's specified rule. A coordinator announcement then informs the nodes.

### Bully election
A node contacts all higher-ID nodes. If none replies, it becomes coordinator. If any replies OK, a higher node takes over the election. The highest active ID eventually wins. The algorithm assumes unique IDs and that nodes can detect failures.

### Cristian's algorithm
A client asks a time server for its time. With send time T0, server time Ts and receive time T1, RTT = T1 - T0. Under symmetric delay, estimated server time at receipt = Ts + RTT/2. Network asymmetry and variable delay reduce accuracy.

### Berkeley algorithm
A master polls node clocks, estimates offsets, excludes faulty/outlier readings, computes an average and sends adjustments. It synchronizes a group to a common time rather than relying on one external time server.

### RPC and RMI
RPC invokes a procedure on another machine; RMI invokes methods on remote objects. Typical stages are client stub, marshalling, transport, server dispatcher, execution, response and unmarshalling. The lab code simulates these stages locally.

### Marshalling
Marshalling converts arguments/results into a representation suitable for transfer. Unmarshalling reconstructs the data at the receiving side.

### Failure and fault tolerance
A failure is when a component stops providing its expected service. Fault tolerance is the ability to continue operating despite failures. Leader election helps restore coordination but does not itself replicate data or guarantee availability.

### Common viva questions with short answers

1. **Why do we need clock synchronization?** To make timestamps and time-dependent operations consistent across machines.
2. **Why can physical clocks differ?** Clock drift, clock skew, hardware variation and network delay.
3. **What is clock drift?** The rate at which a clock gains or loses time relative to a reference.
4. **What is clock skew?** The difference between two clocks at a given instant.
5. **Does Lamport clock give actual time?** No; it gives logical ordering.
6. **What is happens-before?** A relation capturing causal order between events.
7. **Can Lamport clocks identify concurrency?** Not reliably; vector clocks can.
8. **What is a coordinator?** A node responsible for coordinating certain distributed activities.
9. **Why is it called Bully?** Higher-ID processes can take over an election from lower-ID processes.
10. **Ring vs Bully?** Ring circulates election information around a logical ring; Bully sends election messages to all higher-ID processes.
11. **What if the highest-ID node fails?** The next-highest active node becomes leader.
12. **What is RTT?** Total elapsed time for a request to go to a server and the response to return.
13. **Why divide RTT by two in Cristian's algorithm?** It estimates one-way delay under a symmetric-delay assumption.
14. **Who initiates Berkeley synchronization?** The master/coordinator.
15. **Why discard faulty clocks?** Bad readings can distort the computed average.
16. **What is RPC?** A mechanism for calling a procedure on a remote system.
17. **RPC vs local function call?** RPC involves communication, serialization, network delay and remote failure.
18. **What is a stub?** A local proxy/helper that hides communication details from the caller.
19. **What is marshalling?** Packing arguments into a transferable format.
20. **What is idempotency?** Repeating an operation has the same effect as performing it once; important when RPC retries occur.
21. **What is MPI?** Message Passing Interface, a standard for process communication in parallel computing.
22. **What is scatter?** Distributing input/work to workers.
23. **What is gather?** Collecting worker results.
24. **Why parallelize matrix multiplication?** Independent rows or blocks can be calculated concurrently.
25. **What is a race condition?** Output depends on unpredictable timing of concurrent operations.
26. **Does this code use real MPI?** No. It simulates scatter-gather using Python threads.
27. **Why use CSV?** It provides simple structured input that can be edited without changing program code.
28. **What is fault tolerance?** Continuing service despite component failures.
29. **Does leader election replicate data?** No; it selects a coordinator, not a backup copy of application data.
30. **What are the limitations of these simulations?** They simplify network communication, message loss, timing uncertainty and real machine failures.
