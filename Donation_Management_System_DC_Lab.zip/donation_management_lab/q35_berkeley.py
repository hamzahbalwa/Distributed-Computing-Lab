import csv

CSV_FILE = "node_clocks_35.csv"

def truthy(value):
    return str(value).strip().upper() in {"TRUE", "1", "YES", "Y"}

def main():
    with open(CSV_FILE, newline="") as f:
        rows = list(csv.DictReader(f))

    valid = []
    print("[MASTER] Polling node clocks:")
    for r in rows:
        node = r["node_id"]
        clock = float(r["clock_time_sec"])
        faulty = truthy(r["is_faulty"])
        print(f"  {node}: {clock} sec | faulty={faulty}")
        if faulty:
            print(f"  [DISCARD] {node} excluded as faulty.")
        else:
            valid.append((node, clock))

    if not valid:
        print("No valid clocks available.")
        return

    average = sum(clock for _, clock in valid) / len(valid)
    print(f"\n[MASTER] Average of valid clocks = {average:.2f} sec")
    print("[ADJUSTMENTS] Positive means move clock forward; negative means move backward.")
    for node, clock in valid:
        adjustment = average - clock
        print(f"  {node}: {adjustment:+.2f} sec")

if __name__ == "__main__":
    main()
