import csv
from concurrent.futures import ThreadPoolExecutor

CSV_FILE = "matrix_30.csv"

def worker(row_number, row, matrix_b):
    # Each worker calculates one output row of A x B.
    output = []
    for col in range(len(matrix_b[0])):
        value = sum(row[k] * matrix_b[k][col] for k in range(len(row)))
        output.append(value)
    print(f"[WORKER {row_number}] computed row -> {output}")
    return row_number, output

def main():
    with open(CSV_FILE, newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    A = [[int(r[f"col_{i}"]) for i in range(4)] for r in rows]
    if not A or any(len(row) != 4 for row in A):
        raise ValueError("Expected a non-empty matrix with four columns.")

    # The manual supplies only A. For a complete runnable example, use B = transpose(A).
    B = [list(col) for col in zip(*A)]

    print("[MASTER] Matrix A:", A)
    print("[MASTER] Matrix B = transpose(A):", B)
    print("[SCATTER] Assigning one row of A to each worker.")

    result = [None] * len(A)
    with ThreadPoolExecutor(max_workers=min(4, len(A))) as pool:
        futures = [pool.submit(worker, i, row, B) for i, row in enumerate(A)]
        for future in futures:
            index, output_row = future.result()
            result[index] = output_row

    print("[GATHER] Master collected all worker rows.")
    print("Final product A x A^T:")
    for row in result:
        print(row)

if __name__ == "__main__":
    main()
