import csv

CSV_FILE = "bully_cluster_34.csv"

def alive(value):
    return str(value).strip().upper() in {"TRUE", "1", "YES", "Y"}

def main():
    with open(CSV_FILE, newline="") as f:
        rows = list(csv.DictReader(f))

    nodes = {int(r["node_id"]): alive(r["is_alive"]) for r in rows}
    coordinators = [int(r["node_id"]) for r in rows
                    if alive(r["is_current_coordinator"])]

    initiator = min((nid for nid, ok in nodes.items() if ok), default=None)
    if initiator is None:
        print("No active nodes available.")
        return

    print(f"[FAILURE] Coordinator {coordinators[0] if coordinators else 'unknown'} is unavailable.")
    print(f"[ELECTION] Node {initiator} starts election.")
    higher_alive = [nid for nid, ok in nodes.items() if ok and nid > initiator]

    for nid in sorted(higher_alive):
        print(f"  Node {initiator} -> Node {nid}: ELECTION")
        print(f"  Node {nid} -> Node {initiator}: OK")

    leader = max(nid for nid, ok in nodes.items() if ok)
    print(f"[COORDINATOR] Highest active node {leader} declares itself leader.")
    for nid, ok in sorted(nodes.items()):
        if ok and nid != leader:
            print(f"  Node {leader} -> Node {nid}: COORDINATOR")

if __name__ == "__main__":
    main()
