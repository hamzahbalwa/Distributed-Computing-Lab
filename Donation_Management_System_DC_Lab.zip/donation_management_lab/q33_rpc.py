import csv

CSV_FILE = "rpc_calls_33.csv"

def process_donation(amount):
    # Example server-side donation processing operation.
    return {"status": "ACCEPTED", "donation_amount": amount,
            "receipt_message": f"Donation of {amount:.2f} processed"}

def verify_donation(amount):
    return {"verified": amount > 0, "amount": amount}

METHODS = {
    "processDonation": process_donation,
    "processData": process_donation,
    "verifyDonation": verify_donation,
}

def main():
    with open(CSV_FILE, newline="") as f:
        calls = list(csv.DictReader(f))

    for call in calls:
        call_id = call["call_id"]
        client = call["client_name"]
        method = call["method_name"]
        raw_argument = call["param_value"]

        print(f"\n[DISPATCH] {client} invokes {method} (call {call_id})")
        # Marshalling: convert CSV text into the numeric argument expected by server.
        argument = float(raw_argument)
        print(f"[MARSHALLING] Argument converted to number: {argument}")

        if method not in METHODS:
            print(f"[SERVER ERROR] Unknown method: {method}")
            continue

        print(f"[SERVER EXECUTION] Processing donation parameter: {argument}")
        result = METHODS[method](argument)
        # Unmarshalling: client receives the returned Python object.
        print(f"[RETURN] Result sent to client: {result}")

if __name__ == "__main__":
    main()
