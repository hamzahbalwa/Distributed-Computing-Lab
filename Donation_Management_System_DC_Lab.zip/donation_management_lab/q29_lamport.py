import csv
from collections import defaultdict, deque

CSV_FILE = "events_29.csv"
PROCESSES = ("P1", "P2", "P3")

def truthy(value):
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y"}

def main():
    clocks = defaultdict(int)
    mailboxes = defaultdict(deque)
    results = []

    with open(CSV_FILE, newline="") as f:
        events = list(csv.DictReader(f))

    for row in events:
        eid = row["event_id"].strip()
        pid = row["process_id"].strip()
        kind = row["event_type"].strip().upper()
        target = row["message_to"].strip()
        clocks[pid] = max(clocks[pid], int(row["initial_clock"] or 0))

        if kind == "RECEIVE":
            if not mailboxes[(pid, target)]:
                print(f"[WARNING] {eid}: no queued message from {target}; treating as local event")
                clocks[pid] += 1
            else:
                msg_time = mailboxes[(pid, target)].popleft()
                clocks[pid] = max(clocks[pid], msg_time) + 1
        else:
            clocks[pid] += 1

        timestamp = clocks[pid]
        if kind == "SEND":
            mailboxes[(target, pid)].append(timestamp)

        results.append((timestamp, pid, eid, kind))
        print(f"{eid}: process={pid}, type={kind}, Lamport clock={timestamp}")

    print("\nTotal order (Lamport timestamp, then process ID for ties):")
    for item in sorted(results):
        print(f"  time={item[0]} | process={item[1]} | event={item[2]} | {item[3]}")

if __name__ == "__main__":
    main()
