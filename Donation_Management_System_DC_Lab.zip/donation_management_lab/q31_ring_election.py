import csv

CSV_FILE = "ring_nodes_31.csv"

def active(value):
    return str(value).strip().upper() in {"TRUE", "1", "YES", "Y"}

def main():
    with open(CSV_FILE, newline="") as f:
        nodes = list(csv.DictReader(f))

    by_id = {int(r["node_id"]): r for r in nodes}
    alive = {nid for nid, row in by_id.items() if active(row["is_active"])}
    if not alive:
        print("No active nodes. Election cannot proceed.")
        return

    # Use next_node_id to show the configured ring traversal.
    start = min(alive)
    current = start
    visited = set()
    token = []

    print("[FAILURE] Existing coordinator is assumed to have failed.")
    print("[ELECTION] Circulating election token through active ring nodes.")
    while current not in visited:
        visited.add(current)
        if current in alive:
            token.append(current)
            print(f"  Token visits node {current}")
        next_id = int(by_id[current]["next_node_id"])
        # Skip failed nodes by following their next pointers.
        hops = 0
        while next_id not in alive and next_id in by_id and hops < len(by_id):
            next_id = int(by_id[next_id]["next_node_id"])
            hops += 1
        if next_id not in by_id or next_id not in alive:
            break
        current = next_id

    # Include any active node not reached due to a malformed/incomplete ring.
    for nid in sorted(alive - set(token)):
        token.append(nid)
        print(f"  Token visits node {nid} (unreached node fallback)")

    leader = max(token)
    print(f"[ELECTION RESULT] Highest active node ID = {leader}")
    print(f"[COORDINATOR] Node {leader} broadcasts COORDINATOR.")

if __name__ == "__main__":
    main()
