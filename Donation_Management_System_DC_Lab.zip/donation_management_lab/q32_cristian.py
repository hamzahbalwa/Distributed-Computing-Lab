import csv

CSV_FILE = "cristian_clocks_32.csv"

def main():
    with open(CSV_FILE, newline="") as f:
        rows = list(csv.DictReader(f))

    for r in rows:
        client = r["client_id"]
        t0 = float(r["t0_send_ms"])
        ts = float(r["t_server_ms"])
        t1 = float(r["t1_recv_ms"])

        rtt = t1 - t0
        estimated_server_at_receive = ts + rtt / 2
        # Client's clock at receipt is represented by t1 in this dataset.
        offset = estimated_server_at_receive - t1

        print(f"\nClient: {client}")
        print(f"RTT = T1 - T0 = {t1} - {t0} = {rtt} ms")
        print(f"Estimated server time at reception = Ts + RTT/2 = {estimated_server_at_receive} ms")
        print(f"Client time at reception = {t1} ms")
        print(f"Required client adjustment = {offset:+.2f} ms")

if __name__ == "__main__":
    main()
